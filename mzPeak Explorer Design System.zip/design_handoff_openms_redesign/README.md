# Handoff: mzPeak Explorer — OpenMS Redesign

## Overview

This package redesigns **mzPeak Explorer** (https://github.com/okohlbacher/mzPeakExplorer)
to the **OpenMS** visual identity and a modern, slim, persistent app shell that
stays fixed while the **Summary / Metadata / Browse** views swap inside it —
visually concordant with the sibling app **mzPeakIV**.

The redesign:
- Re-skins the app to the OpenMS palette (electric blue `#3B54DA` accent, signal
  red flourish, the OpenMS rainbow spectrum for branding only).
- Switches type to **IBM Plex Sans** (chrome) + **IBM Plex Mono** (every measured
  value).
- Replaces the three top tabs with a **persistent shell**: top bar (OpenMS logo +
  product lockup), a fixed left **nav rail** with a pinned **file inspector**, and
  a scrolling **main pane**.
- Moves the Browse **chromatogram + spectrum plots onto a dark "data stage"**
  (`#0e1216` with a faint dot-grid), the OpenMS treatment for data visualisation.
- Adds the official **OpenMS logo**.

## About the design files

The files in `reference-prototype/` are **design references built in HTML/JSX**
(React via in-browser Babel) — prototypes that show the intended look and
behaviour. **They are not production code to copy verbatim.** Your job is to
**recreate these designs in the real mzPeakExplorer codebase** (Vite 8 + React 19
+ TypeScript) using its existing patterns — its zustand store, its uPlot charts,
its component structure under `src/ui/`.

`design-system/` contains **drop-in CSS tokens** (`styles.css` + `tokens/`) and
the **brand assets** — these you *can* lift directly.

## Fidelity

**High-fidelity.** Final colours, type, spacing, layout and interactions are all
specified. Recreate the UI pixel-faithfully using the codebase's existing
libraries (React, uPlot, zustand). Exact hex values, fonts and measurements are
given below and in `design-system/tokens/`.

---

## How to apply it to the codebase (file-by-file)

The original app structure (from the repo):
```
src/ui/styles.css          ← global CSS + :root tokens
src/ui/App.tsx             ← header + tabbar + tab body (REPLACE shell)
src/ui/FileLoader.tsx      ← drop-zone + URL loader
src/ui/SummaryTab.tsx      ← FileInfo-style stat grid + tables
src/ui/MetadataTab.tsx     ← metadata tree toolbar
src/ui/TreeView.tsx        ← the collapsible syntax-highlighted tree
src/ui/BrowseTab.tsx       ← controls + chromatogram + spectrum
src/ui/ChromPlot.tsx       ← uPlot chromatogram
src/ui/SpectrumPlot.tsx    ← uPlot spectrum
src/state/store.ts         ← zustand store (UNCHANGED)
```

### 1. Tokens — `src/ui/styles.css`

Replace the `:root` block at the top of `src/ui/styles.css` with the contents of
**`design-system/tokens/colors.css` + `typography.css` + `spacing.css`** (or
`@import` them). Then update the existing rules to use the new variable names —
most already reference `--accent`, `--border`, `--panel`, `--muted`, `--mono`,
which are preserved as aliases, so the bulk keeps working. Key value changes:

- `--accent` is now **`#3b54da`** (was `#1565c0`). Hover **darkens** to `#2f44bf`,
  active `#263799`.
- `--mono` → `var(--font-mono)` = **IBM Plex Mono**; body font → **IBM Plex Sans**.
- Body font-size **13px** (was 14px); the working UI size is **12.5px**.
- `--panel` is now white-ish `#f4f6f8`; cards become **white** with a `#dde2e7`
  hairline (no shadow).

### 2. Fonts — `index.html`

Add IBM Plex before the app mounts (the prototype uses Google Fonts; self-host
for production):
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
```
(Or keep `design-system/tokens/fonts.css` which `@import`s the same.)

### 3. App shell — `src/ui/App.tsx`  ← the biggest change

Replace the `header + tabbar + tab-body` structure with a **persistent shell**.
Reference: `reference-prototype/app.jsx`.

```
┌── top bar (52px, white, hairline-bottom) ───────────────────────────┐
│  [OpenMS logo] │ mzPeak Explorer        [file chip]  [Open file ▸]   │
├──[2px OpenMS-spectrum gradient strip]───────────────────────────────┤
│ nav rail   │  main pane (scrolls; the active view renders here)      │
│ (220px)    │                                                          │
│  ▸ Summary │                                                          │
│  ▸ Metadata│                                                          │
│  ▸ Browse  │                                                          │
│  …         │                                                          │
│ ──────────  (file mini-inspector pinned to rail bottom) ─────────────│
│  FILE       Spectra 1,684 · m/z 86–800 · Layout chunked · Imaging no  │
└────────────┴─────────────────────────────────────────────────────────┘
```
- The shell (top bar + rail + inspector) is **invariant**; only the main pane
  swaps between Summary / Metadata / Browse. Drive the active view from the
  existing `tab` state in the store; nav items call `setTab`.
- **Nav item** (active): `2px` left border `--accent`, background `--accent-soft`
  (`#f2f4fe`), text `--accent-active`, weight 600. Inactive: text `--text-secondary`,
  hover background `--surface-panel`.
- **File mini-inspector**: pinned to the rail bottom (`margin-top:auto`),
  hairline-top, an uppercase overline "FILE" then key/value rows (mono values).
  Mirrors mzPeakIV's persistent StatsPanel.
- **Responsive:** below ~760px the rail collapses to a horizontal scrolling strip
  under the top bar (see `app.jsx` `narrow` branch). ⚠️ Position any responsive
  overlay with `left`/conditional mount, **not** a CSS `transform` slide-in.

### 4. File loader — `src/ui/FileLoader.tsx`

Keep behaviour. The drop-zone restyles to the new tokens: `2px dashed
--border-default`, radius `--radius-md` (6px), drag-over → border `--accent` +
background `--accent-soft`. The **idle empty state** centres the OpenMS logo, a
short intro, and a large drop-zone (see `app.jsx` idle branch + `views.jsx`).

### 5. Summary — `src/ui/SummaryTab.tsx`

Reference: `reference-prototype/views.jsx` (`SummaryView`).
- **Stat cards** (`.stat-card`): **white**, `1px #dde2e7` hairline, radius 8px,
  **no shadow**. Caption = uppercase overline `10.5px/600/0.06em --text-muted`.
  Value `20px/600 --text-heading`; the headline figure (Spectra) value is
  `--accent` blue. Unit (`Th`, `s`) is small + muted, inline.
- **Section headings** become **uppercase overlines** (`10.5px/600/0.06em`,
  `--text-muted`), not the old `h3.section`.
- **Tables** (`table.data`): unchanged structure; muted heads, hairline rows,
  `tabular-nums` on numeric cells.
- **Encoding chips**: pill badges, soft purple tone (`#f6ecfb` bg, `#b026d3`
  text), mono.

### 6. Metadata — `src/ui/MetadataTab.tsx` + `src/ui/TreeView.tsx`

Structure unchanged. Only the **syntax colours** change (already CSS vars in the
original — just retune them):
- key `--tree-key` → `#b026d3` (brand purple)
- CV accession `--tree-cv` → `#3b54da` (accent blue)
- number/bool `--tree-val` → `#2e9e5b` (green)
- string `--tree-val.str` → `#c2410c` (burnt orange)
Toolbar buttons use the new Button styles.

### 7. Browse — `src/ui/BrowseTab.tsx` (the **dark data stage**)

Reference: `reference-prototype/views.jsx` (`BrowseView`) + `plots.jsx`.
- Controls row (prev/next, spectrum index, MS-level select, XIC m/z + tol +
  Extract) stays on **light** chrome. "Extract" is the primary (blue) button.
- The **chromatogram + spectrum sit inside one dark "stage" panel**:
  - background `--surface-stage` **`#0e1216`**, `1px #2a323a` border, radius 8px,
    with a faint dot-grid: `background-image: radial-gradient(rgba(255,255,255,.045) 1px, transparent 1px); background-size: 22px 22px;`
  - Each plot has a header row: title in light `--text-on-stage` (`#eceff2`) +
    mono meta in `--text-faint` (`#9aa4ad`). A `1px #2a323a` divider separates the
    two plots.
- The **"Spectrum metadata"** collapsible tree moves **below the stage**, on light
  chrome (it's inspector content, not stage content).

### 8. Charts — `src/ui/ChromPlot.tsx` + `src/ui/SpectrumPlot.tsx`

These use **uPlot**; retheme for the dark stage (the original hard-codes
`#1565c0` / `#e53935` etc.):
- Series stroke (spectrum line / chromatogram): **`#5468e0`** (bright blue on dark).
- Profile-spectrum fill: `rgba(84,104,224,0.18)`.
- Selected-time marker (the vertical line drawn in ChromPlot's `draw` hook):
  **`#d62828`** (signal red).
- XIC band (`drawXicBand`): **`rgba(255,200,0,0.22)`** (warning yellow).
- Peak labels: `#c5ccd3`. Axis tick text: `#9aa4ad`. Gridlines: `#2a323a`.
- uPlot host background transparent; the dark stage shows through. Set uPlot
  axis `stroke`/`grid.stroke`/`ticks.stroke` to the values above, and make the
  `<u-wrap>`/canvas inherit the stage background.
- The hover tooltip (`.spec-tooltip`) → `rgba(14,18,22,0.82)` with a 10%-white
  hairline; reserve the translucent + `backdrop-filter: blur(8px)` treatment for
  on-stage overlays only.

### 9. Logo

Add `design-system/assets/openms-logo.png` to the top bar at ~30px height
(beside the product name "mzPeak Explorer", separated by a 1px divider). Use
`openms-mark.svg` (blue rounded square, white peaks, red baseline) as the favicon
and anywhere the full wordmark won't read. Place the logo on **white/light only**
(its wordmark is near-black).

---

## Interactions & behavior

- **Nav:** clicking a rail item swaps the main pane (`setTab`); the shell is
  static. Items disabled until a file is loaded.
- **Open flow:** idle → (drop/pick/URL) → loading ("Reading file…", spinner) →
  ready (Summary). Matches the store's existing `stage` machine.
- **Browse — chromatogram click:** picks the nearest time → selects the nearest
  spectrum (existing `selectByTime`). Red marker tracks the selection.
- **Browse — XIC:** Extract draws the amber m/z band on the spectrum and switches
  the chromatogram to XIC mode; "Show TIC" reverts.
- **Hover/press:** primary button darkens on hover (`#2f44bf`), `#263799` active;
  secondary/ghost gain accent border/text or a panel fill. Focus ring
  `0 0 0 3px rgba(59,84,218,0.28)`.
- **Motion:** `cubic-bezier(.2,0,0,1)`, 120/180/260ms. Subtle fades only; respect
  `prefers-reduced-motion`. No bounces, no infinite loops.

## State management

No new state. Reuse the existing **zustand store** (`src/state/store.ts`):
`stage`, `tab`, `summary`, `manifest`, `fileMeta`, `spectra`, `selectedIndex`,
`chrom`, `chromMode`, `xicParams`, `msLevelFilter`, etc. The shell binds nav to
`tab`/`setTab` and the mini-inspector to `summary`.

## Design tokens

Authoritative values live in `design-system/tokens/`. Summary:

- **Accent (OpenMS blue):** 50 `#f2f4fe` · 100 `#e6e9fc` · 400 `#7d8ce8` ·
  500 `#5468e0` · **600 `#3b54da`** · 700 `#2f44bf` · 800 `#263799` · 900 `#1b2870`.
- **Signal red:** `#c00000` (600), `#d62828` (500 — marker on dark).
- **OpenMS brand spectrum (flourish only, never data):**
  `linear-gradient(90deg,#f5a623,#f4612e,#f0344e,#e6249e,#b026d3,#6d3be8,#3b5be0)`.
- **Neutrals:** white `#fff` · gray-50 `#f4f6f8` · 100 `#eceff2` · 150 `#e3e7eb` ·
  200 `#dde2e7` (hairline) · 300 `#c5ccd3` · 400 `#9aa4ad` · 500 `#6b757e` ·
  600 `#4b545c` · 700 `#353c43` (body) · 800 `#232a30` · 900 `#151a1e` (headings).
- **Dark stage:** bg `#0e1216` · raised `#161c22` · line `#2a323a` · sentinel
  (no-data) `#1a1a1a`.
- **Semantic:** info `#3b54da` · success `#2e9e5b` · warning `#8a6d00` (band
  `rgba(255,200,0,.25)`) · danger `#c62828`.
- **Type:** IBM Plex Sans / IBM Plex Mono. Scale (px): overline 10.5 · small 11.5 ·
  **base UI 12.5** · 13 · 14 · 16 · 18 · stat 20 · 26 · display 34. Weights
  400/500/600/700. Overlines: uppercase, 600, `letter-spacing 0.06em`, muted.
  Measured figures use `font-variant-numeric: tabular-nums`.
- **Spacing (2px base):** 2 4 6 8 12 16 20 24 32 40 48 64.
- **Radii:** xs 3 (buttons/inputs) · sm 4 (chips) · md 6 (cards/dropzone) ·
  lg 8 (panels) · pill 999.
- **Borders:** 1px hairline `#dde2e7`. No coloured left-border accent cards.
- **Elevation:** mostly none. `--shadow-1 0 1px 2px rgba(16,22,30,.06)` for the
  framed canvas; `--shadow-3 0 6px 18px rgba(16,22,30,.12)` for popovers.
- **Control height:** 28px (small 22px).

## Assets

- `design-system/assets/openms-logo.png` — official OpenMS logo (stacked
  Open/MS wordmark + rainbow stick-spectrum, transparent, 1156×843). Light
  backgrounds only.
- `design-system/assets/openms-mark.svg` — app mark / favicon (blue rounded
  square, white peaks, red baseline).
- **Icons:** Lucide line icons (2px stroke, 24×24, rounded) — used for nav
  (`layout-dashboard`, `list-tree`, `activity`), `folder-open`, `file`,
  `loader-circle`. The prototype inlines them as React-owned SVG
  (`reference-prototype/icons.jsx`) — in the real app, use `lucide-react` rather
  than the DOM-mutating `lucide.createIcons()` (which corrupts React's DOM).

## Files in this bundle

- `design-system/styles.css` — entry point; `@import`s the tokens.
- `design-system/tokens/{colors,typography,spacing,fonts,base}.css` — drop-in.
- `design-system/assets/{openms-logo.png,openms-mark.svg}`.
- `reference-prototype/index.html` — open this to see the full design working
  (click **Open demo**). Source: `app.jsx` (shell + state), `views.jsx`
  (Summary/Metadata/Browse), `plots.jsx` (SVG chromatogram/spectrum + tree),
  `primitives.jsx` (Button/Badge/StatCard/DataTable/TextField/Select/DropZone/
  SideNav/AppHeader/Logo), `icons.jsx`, `mock-data.js`.

> Note: the prototype draws charts with lightweight inline SVG. The real app
> already uses **uPlot** — keep uPlot; only retheme it with the colours above.
> The prototype's fabricated `mock-data.js` mirrors the shapes in the app's
> `src/reader/types.ts`.
