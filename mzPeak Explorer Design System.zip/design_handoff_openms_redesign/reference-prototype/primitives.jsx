/* Local primitives for the UI-kit recreation — visually identical to the
   design-system components (components/*), self-contained so the kit renders
   without the runtime bundle. Consumers should prefer window.<Namespace>. */

function Logo({ product, src = "../../assets/openms-logo.png", size = 30 }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: "0.6rem" }}>
      <img src={src} alt="OpenMS" height={size} style={{ display: "block", height: size, width: "auto", flexShrink: 0 }} />
      {product && (
        <>
          <span aria-hidden="true" style={{ width: 1, height: size * 0.72, background: "var(--border-strong)" }} />
          <span style={{ fontSize: size * 0.5, fontWeight: "var(--weight-title)", color: "var(--text-heading)", letterSpacing: "-0.01em", whiteSpace: "nowrap" }}>{product}</span>
        </>
      )}
    </span>
  );
}

function Button({ children, variant = "secondary", size = "md", iconLeft, iconRight, disabled, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const sizes = { sm: { padding: "0.28rem 0.6rem", fontSize: "var(--text-sm)", gap: "0.3rem" }, md: { padding: "0.4rem 0.85rem", fontSize: "var(--text-body)", gap: "0.4rem" } };
  const hv = hover && !disabled;
  const variants = {
    primary: { background: hv ? "var(--accent-hover)" : "var(--accent)", color: "#fff", borderColor: hv ? "var(--accent-hover)" : "var(--accent)" },
    secondary: { background: "var(--surface-card)", color: hv ? "var(--accent)" : "var(--text-body)", borderColor: hv ? "var(--accent)" : "var(--border-default)" },
    ghost: { background: hv ? "var(--surface-panel)" : "transparent", color: "var(--text-body)", borderColor: "transparent" },
    quiet: { background: "var(--surface-card)", color: hv ? "var(--accent-secondary)" : "var(--text-body)", borderColor: hv ? "var(--accent-secondary)" : "var(--border-default)" },
  };
  return (
    <button type="button" disabled={disabled} onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: sizes[size].gap, padding: sizes[size].padding, fontFamily: "var(--font-sans)", fontSize: sizes[size].fontSize, fontWeight: "var(--weight-medium)", lineHeight: 1.1, border: "1px solid", borderRadius: "var(--radius-sm)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1, transition: "var(--transition-ui)", whiteSpace: "nowrap", ...variants[variant], ...style }} {...rest}>
      {iconLeft}{children}{iconRight}
    </button>
  );
}

function Badge({ children, tone = "slate", shape = "pill", mono, style }) {
  const tones = {
    neutral: { background: "var(--surface-panel)", color: "var(--text-secondary)", border: "var(--border-default)" },
    accent: { background: "var(--surface-accent-soft)", color: "var(--accent-active)", border: "transparent" },
    slate: { background: "var(--surface-slate-soft)", color: "var(--accent-secondary)", border: "transparent" },
    success: { background: "#e7f3e8", color: "var(--green-700)", border: "transparent" },
    muted: { background: "transparent", color: "var(--text-muted)", border: "var(--border-default)" },
  };
  const t = tones[tone] || tones.slate;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: "0.3rem", padding: "0.15rem 0.5rem", fontSize: "var(--text-sm)", fontFamily: mono ? "var(--font-mono)" : "var(--font-sans)", fontWeight: "var(--weight-medium)", lineHeight: 1.4, color: t.color, background: t.background, border: `1px solid ${t.border}`, borderRadius: shape === "pill" ? "var(--radius-pill)" : "var(--radius-sm)", whiteSpace: "nowrap", ...style }}>{children}</span>
  );
}

function StatCard({ label, value, unit, sub, accent, style }) {
  return (
    <div style={{ border: "1px solid var(--border-default)", borderRadius: "var(--radius-lg)", padding: "0.7rem 0.85rem", background: "var(--surface-card)", minWidth: 0, ...style }}>
      <div style={{ fontSize: "var(--text-cap)", textTransform: "uppercase", letterSpacing: "var(--tracking-caps)", color: "var(--text-muted)" }}>{label}</div>
      <div style={{ fontSize: "var(--text-stat)", fontWeight: "var(--weight-semibold)", marginTop: "0.15rem", color: accent ? "var(--accent)" : "var(--text-heading)", wordBreak: "break-word" }}>
        {value}{unit && <span style={{ fontSize: "var(--text-body)", fontWeight: 400, color: "var(--text-muted)" }}> {unit}</span>}
      </div>
      {sub && <div style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)", marginTop: "0.1rem" }}>{sub}</div>}
    </div>
  );
}

function DataTable({ columns, rows, maxWidth, style }) {
  return (
    <table style={{ width: "100%", maxWidth: maxWidth || "none", borderCollapse: "collapse", fontSize: "var(--text-data)", ...style }}>
      <thead><tr>{columns.map((c) => (
        <th key={c.key} style={{ textAlign: c.align || "left", padding: "0.35rem 0.6rem", borderBottom: "1px solid var(--border-default)", color: "var(--text-muted)", fontWeight: "var(--weight-semibold)", width: c.width, whiteSpace: "nowrap" }}>{c.label}</th>
      ))}</tr></thead>
      <tbody>{rows.map((r, i) => (
        <tr key={r.key ?? i}>{columns.map((c) => (
          <td key={c.key} style={{ textAlign: c.align || "left", padding: "0.35rem 0.6rem", borderBottom: "1px solid var(--border-default)", fontFamily: c.mono ? "var(--font-mono)" : "inherit", fontVariantNumeric: "tabular-nums", color: "var(--text-body)" }}>{r[c.key]}</td>
        ))}</tr>
      ))}</tbody>
    </table>
  );
}

function TextField({ label, value, onChange, type = "text", placeholder, suffix, width, style, inputProps = {} }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <label style={{ display: "inline-flex", flexDirection: "column", gap: "0.25rem", ...style }}>
      {label && <span style={{ fontSize: "var(--text-label)", color: "var(--text-muted)" }}>{label}</span>}
      <span style={{ display: "inline-flex", alignItems: "center", gap: "0.4rem", background: "var(--surface-card)", border: `1px solid ${focus ? "var(--accent)" : "var(--border-default)"}`, boxShadow: focus ? "0 0 0 2px var(--accent-soft)" : "none", borderRadius: "var(--radius-sm)", padding: "0 0.5rem", transition: "var(--transition-ui)" }}>
        <input type={type} value={value} onChange={onChange} placeholder={placeholder} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{ border: "none", outline: "none", background: "transparent", font: "inherit", fontSize: "var(--text-body)", color: "var(--text-body)", padding: "0.34rem 0", width: width || "auto", minWidth: 0 }} {...inputProps} />
        {suffix && <span style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{suffix}</span>}
      </span>
    </label>
  );
}

function Select({ label, value, onChange, options, style }) {
  return (
    <label style={{ display: "inline-flex", flexDirection: "column", gap: "0.25rem", ...style }}>
      {label && <span style={{ fontSize: "var(--text-label)", color: "var(--text-muted)" }}>{label}</span>}
      <select value={value} onChange={onChange}
        style={{ font: "inherit", fontSize: "var(--text-body)", color: "var(--text-body)", background: "var(--surface-card)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-sm)", padding: "0.34rem 1.6rem 0.34rem 0.5rem", cursor: "pointer", appearance: "none", backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23687083' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 0.5rem center" }}>
        {options.map((o) => <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>)}
      </select>
    </label>
  );
}

function DropZone({ onFile, hint, big }) {
  const [over, setOver] = React.useState(false);
  const ref = React.useRef(null);
  return (
    <div role="button" tabIndex={0} onClick={() => ref.current?.click()}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") ref.current?.click(); }}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={(e) => { e.preventDefault(); setOver(false); }}
      onDrop={(e) => { e.preventDefault(); setOver(false); onFile && onFile(e.dataTransfer.files?.[0]); }}
      style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem", textAlign: "center", padding: big ? "2.2rem 1rem" : "0.55rem 1rem", border: `2px dashed ${over ? "var(--accent)" : "var(--border-default)"}`, borderRadius: "var(--radius-lg)", background: over ? "var(--accent-soft)" : "var(--surface-panel)", color: over ? "var(--accent)" : "var(--text-muted)", cursor: "pointer", fontSize: "var(--text-body)", transition: "var(--transition-ui)", userSelect: "none" }}>
      {hint || <span>Drop a <strong style={{ color: over ? "var(--accent)" : "var(--text-body)" }}>.mzpeak</strong> file, or <u>browse</u></span>}
      <input ref={ref} type="file" accept=".mzpeak" style={{ display: "none" }} onChange={(e) => { onFile && onFile(e.target.files?.[0]); e.target.value = ""; }} />
    </div>
  );
}

function SideNav({ items, activeId, onSelect, footer }) {
  const [hoverId, setHoverId] = React.useState(null);
  return (
    <nav style={{ display: "flex", flexDirection: "column", gap: "0.15rem", padding: "0.5rem", height: "100%", boxSizing: "border-box" }}>
      {items.map((it) => {
        const active = it.id === activeId;
        const hovered = it.id === hoverId && !active && !it.disabled;
        const bg = active ? "var(--accent-soft)" : hovered ? "var(--surface-panel)" : "transparent";
        return (
          <button key={it.id} type="button" disabled={it.disabled} onClick={() => !it.disabled && onSelect(it.id)}
            onMouseEnter={() => setHoverId(it.id)} onMouseLeave={() => setHoverId(null)}
            style={{ display: "flex", alignItems: "center", gap: "0.6rem", width: "100%", padding: "0.46rem 0.6rem", border: "none", borderLeft: `2px solid ${active ? "var(--accent)" : "transparent"}`, borderRadius: "var(--radius-sm)", background: bg, color: active ? "var(--accent-active)" : it.disabled ? "var(--text-muted)" : "var(--text-secondary)", font: "inherit", fontSize: "var(--text-body)", fontWeight: active ? "var(--weight-semibold)" : "var(--weight-medium)", cursor: it.disabled ? "not-allowed" : "pointer", opacity: it.disabled ? 0.55 : 1, textAlign: "left" }}>
            {it.icon && <span style={{ display: "inline-flex", width: 17, height: 17, flexShrink: 0 }}>{it.icon}</span>}
            <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{it.label}</span>
            {it.badge != null && <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>{it.badge}</span>}
          </button>
        );
      })}
      {footer && <div style={{ marginTop: "auto" }}>{footer}</div>}
    </nav>
  );
}

function AppHeader({ left, right }) {
  return (
    <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem", height: 52, padding: "0 1rem", background: "var(--surface-page)", borderBottom: "1px solid var(--border-default)", flexShrink: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: "0.85rem", minWidth: 0 }}>{left}</div>
      <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", minWidth: 0 }}>{right}</div>
    </header>
  );
}

Object.assign(window, { Logo, Button, Badge, StatCard, DataTable, TextField, Select, DropZone, SideNav, AppHeader });
