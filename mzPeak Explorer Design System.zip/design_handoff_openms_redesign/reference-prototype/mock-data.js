/* Mock mzPeak file data for the UI-kit recreation.
   Modelled on the OpenMS FileInfo example.mzML readout:
   LTQ Orbitrap XL · 1,684 spectra · MS1 564 / MS2 1,120 ·
   m/z 85.81–799.95 · RT 1501–2499 s. Everything is fabricated
   for display; no real signal is read.                          */
(function () {
  // ---- deterministic PRNG so the synthetic spectra are stable ----
  function rng(seed) {
    let s = seed >>> 0;
    return function () {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }

  const NUM = 1684;
  const RT0 = 1501.41,
    RT1 = 2499.52;

  // Per-spectrum index: alternate MS1 (profile) / MS2 (centroid) like a real
  // data-dependent run — one MS1 survey followed by a few MS2.
  const index = [];
  let t = RT0;
  const dt = (RT1 - RT0) / NUM;
  for (let i = 0; i < NUM; i++) {
    const isMs1 = i % 4 === 0; // ~1 in 4 is an MS1 survey
    index.push({
      i,
      id: `controllerType=0 controllerNumber=1 scan=${1000 + i}`,
      msLevel: isMs1 ? 1 : 2,
      representation: isMs1 ? "profile" : "centroid",
      time: +(t).toFixed(2),
      tic: 0, // filled below
    });
    t += dt;
  }

  // ---- synthesise a spectrum's peak list on demand ----
  function makeSpectrum(row) {
    const r = rng(1000 + row.i * 7 + 3);
    const peaks = [];
    if (row.msLevel === 1) {
      // MS1 profile: a handful of isotope envelopes across the range
      const nEnv = 6 + Math.floor(r() * 4);
      for (let e = 0; e < nEnv; e++) {
        const base = 120 + r() * 640;
        const charge = 1 + Math.floor(r() * 2);
        const amp = 0.25 + r() * 0.95;
        for (let iso = 0; iso < 4; iso++) {
          peaks.push({ mz: base + (iso * 1.0033) / charge, int: amp * Math.exp(-iso * 0.55) });
        }
      }
    } else {
      // MS2 centroid: fragment sticks
      const n = 18 + Math.floor(r() * 26);
      for (let k = 0; k < n; k++) {
        peaks.push({ mz: 90 + r() * 700, int: 0.05 + Math.pow(r(), 2.2) });
      }
    }
    peaks.sort((a, b) => a.mz - b.mz);
    const maxInt = Math.max(...peaks.map((p) => p.int));
    const norm = peaks.map((p) => ({ mz: +p.mz.toFixed(4), int: +(p.int / maxInt).toFixed(4) }));
    return {
      ...row,
      representation: row.representation,
      peaks: norm,
      basePeak: norm.reduce((a, b) => (b.int > a.int ? b : a), norm[0]),
      precursor: row.msLevel === 2 ? +(150 + rng(row.i * 13 + 5)() * 600).toFixed(2) : null,
    };
  }

  // ---- TIC: one point per spectrum, smooth-ish elution profile ----
  const tic = [];
  const tr = rng(99);
  for (let i = 0; i < NUM; i++) {
    const x = i / NUM;
    // a few overlapping chromatographic peaks
    let v =
      0.55 * Math.exp(-Math.pow((x - 0.28) / 0.06, 2)) +
      0.9 * Math.exp(-Math.pow((x - 0.46) / 0.05, 2)) +
      0.7 * Math.exp(-Math.pow((x - 0.62) / 0.08, 2)) +
      0.4 * Math.exp(-Math.pow((x - 0.8) / 0.05, 2));
    v += 0.03 + tr() * 0.04; // baseline + noise
    const intensity = +(v * 1.2e7).toFixed(0);
    index[i].tic = intensity;
    tic.push({ time: index[i].time, i, intensity });
  }

  const manifest = [
    { name: "spectrum_index", entityType: "spectrum", dataKind: "index" },
    { name: "spectrum_data", entityType: "spectrum", dataKind: "point" },
    { name: "chromatogram_index", entityType: "chromatogram", dataKind: "index" },
    { name: "chromatogram_data", entityType: "chromatogram", dataKind: "point" },
    { name: "mz_array", entityType: "spectrum", dataKind: "array" },
    { name: "intensity_array", entityType: "spectrum", dataKind: "array" },
  ];

  const metadata = {
    fileDescription: {
      fileContent: { "MS:1000579": "MS1 spectrum", "MS:1000580": "MSn spectrum" },
      sourceFiles: [{ id: "RAW1", name: "example.raw", "MS:1000768": "Thermo nativeID format" }],
      contacts: [{ "MS:1000586": "J. Doe", "MS:1000590": "Tübingen" }],
    },
    instrumentConfigurations: [
      {
        id: "IC1",
        "MS:1000449": "LTQ Orbitrap XL",
        components: { source: "MS:1000073 (ESI)", analyzer: "MS:1000484 (orbitrap)", detector: "MS:1000624 (inductive)" },
      },
    ],
    software: [
      { id: "Xcalibur", version: "2.7", "MS:1000532": "Xcalibur" },
      { id: "mzpeak-convert", version: "0.4.1", "MS:1003356": "mzpeak converter" },
    ],
    dataProcessing: [
      { id: "DP1", "MS:1000035": "peak picking", software_ref: "mzpeak-convert", order: 1 },
    ],
    run: { id: "run1", "MS:1000857": "example", startTimeStamp: "2024-03-11T09:41:22Z", defaultInstrument: "IC1" },
    samples: [{ id: "S1", name: "HeLa tryptic digest", "MS:1000004": 1.0 }],
    "index.metadata": {
      mzpeak_version: "0.3.0-unstable",
      created_by: "imzML2mzPeak 0.4.1",
      storage_layout: "chunked",
      entities: 6,
    },
  };

  const summary = {
    fileName: "example.mzpeak",
    fileSize: 248 * 1024 * 1024,
    numSpectra: NUM,
    numChromatograms: 1,
    numEntities: 6,
    msLevelCounts: { 1: 564, 2: 1120 },
    representationCounts: { profile: 564, centroid: 1120, unknown: 0 },
    mzRange: [85.81, 799.95],
    rtRange: [RT0, RT1],
    layout: "chunked",
    encodings: ["MS:1000523 · 64-bit float", "MS:1000521 · 32-bit float", "MS:1000574 · zlib"],
    isImaging: false,
    instrument: "LTQ Orbitrap XL",
  };

  window.MZ_DATA = { summary, manifest, metadata, index, tic, makeSpectrum };
})();
