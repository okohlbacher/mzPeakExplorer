/* The three swapping views — Summary, Metadata, Browse. They consume the
   window primitives + plots + window.MZ_DATA. */

function SectionH({ children, right }) {
  return (
    <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", margin: "1.2rem 0 0.45rem" }}>
      <h3 style={{ margin: 0, fontSize: "var(--text-cap)", fontWeight: "var(--weight-semibold)", textTransform: "uppercase", letterSpacing: "var(--tracking-caps)", color: "var(--text-muted)", whiteSpace: "nowrap" }}>{children}</h3>
      {right}
    </div>
  );
}

function SummaryView() {
  const { summary: s, manifest } = window.MZ_DATA;
  const fmtBytes = (b) => { const u = ["B", "KB", "MB", "GB", "TB"]; let v = b, i = 0; while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; } return `${v.toFixed(v < 10 && i ? 1 : 0)} ${u[i]}`; };
  const reps = s.representationCounts;
  const repStr = [reps.profile && `${reps.profile.toLocaleString()} profile`, reps.centroid && `${reps.centroid.toLocaleString()} centroid`].filter(Boolean).join(" · ");
  const lvls = Object.keys(s.msLevelCounts).map(Number);
  return (
    <div style={{ maxWidth: 1080 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(190px, 1fr))", gap: "0.7rem" }}>
        <StatCard label="File" value={<span style={{ fontSize: "15px", wordBreak: "break-all" }}>{s.fileName}</span>} sub={fmtBytes(s.fileSize)} />
        <StatCard label="Spectra" value={s.numSpectra.toLocaleString()} accent />
        <StatCard label="Chromatograms" value={s.numChromatograms} />
        <StatCard label="Entities" value={s.numEntities} />
        <StatCard label="m/z range" value={`${s.mzRange[0].toFixed(2)} – ${s.mzRange[1].toFixed(2)}`} unit="Th" />
        <StatCard label="RT range" value={`${s.rtRange[0].toFixed(0)} – ${s.rtRange[1].toFixed(0)}`} unit="s" />
        <StatCard label="Storage layout" value={<span style={{ textTransform: "capitalize" }}>{s.layout}</span>} />
        <StatCard label="Instrument" value={s.instrument} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(280px, 360px) 1fr", gap: "2rem", alignItems: "start" }}>
        <div>
          <SectionH>MS levels</SectionH>
          <DataTable maxWidth={340}
            columns={[{ key: "lvl", label: "MS level" }, { key: "n", label: "Spectra", align: "right" }, { key: "pct", label: "Share", align: "right" }]}
            rows={lvls.map((l) => ({ lvl: `MS${l}`, n: s.msLevelCounts[l].toLocaleString(), pct: `${((100 * s.msLevelCounts[l]) / s.numSpectra).toFixed(1)}%` }))} />
          <SectionH>Spectrum representation</SectionH>
          <p style={{ margin: 0, fontSize: "var(--text-body)", color: "var(--text-secondary)" }}>{repStr}</p>
        </div>
        <div>
          <SectionH>Array encodings</SectionH>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem" }}>
            {s.encodings.map((e) => <Badge key={e} tone="slate" mono>{e}</Badge>)}
          </div>
          <SectionH>Entities <span style={{ color: "var(--text-muted)", fontWeight: 400 }}>({manifest.length})</span></SectionH>
          <DataTable
            columns={[{ key: "name", label: "Name", mono: true }, { key: "entityType", label: "Entity" }, { key: "dataKind", label: "Kind" }]}
            rows={manifest} />
        </div>
      </div>
    </div>
  );
}

function MetadataView() {
  const { metadata } = window.MZ_DATA;
  const [depth, setDepth] = React.useState(1);
  const [nonce, setNonce] = React.useState(0);
  const apply = (d) => { setDepth(d); setNonce((n) => n + 1); };
  const groups = Object.entries(metadata);
  return (
    <div style={{ maxWidth: 880 }}>
      <div style={{ display: "flex", gap: "0.5rem", alignItems: "center", marginBottom: "0.7rem" }}>
        <Button size="sm" onClick={() => apply(99)}>Expand all</Button>
        <Button size="sm" onClick={() => apply(1)}>Collapse</Button>
        <span style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)", marginLeft: "0.25rem" }}>Click a node to expand or collapse it.</span>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "0.2rem" }}>
        {groups.map(([label, value]) => <MetaTree key={`${label}-${nonce}`} label={label} value={value} defaultOpen={depth} />)}
      </div>
    </div>
  );
}

function BrowseView() {
  const { index, tic, makeSpectrum, summary } = window.MZ_DATA;
  const [sel, setSel] = React.useState(64);
  const [lvl, setLvl] = React.useState("all");
  const [mz, setMz] = React.useState("");
  const [tol, setTol] = React.useState("0.01");
  const [xic, setXic] = React.useState(null);

  const matches = (i) => lvl === "all" || index[i].msLevel === Number(lvl);
  function step(dir) {
    let i = sel + dir;
    while (i >= 0 && i < index.length && !matches(i)) i += dir;
    if (i >= 0 && i < index.length) setSel(i);
  }
  function selByTime(t) {
    let best = 0, bd = Infinity;
    index.forEach((r, i) => { if (matches(i)) { const d = Math.abs(r.time - t); if (d < bd) { bd = d; best = i; } } });
    setSel(best);
  }
  const spec = makeSpectrum(index[sel]);
  const row = index[sel];
  const chromTitle = xic ? `XIC — m/z ${xic.mz} ± ${xic.tol}` : "Total ion chromatogram";
  function extract() {
    const m = Number(mz), t = Number(tol);
    if (m > 0 && t > 0) setXic({ mz: m, tol: t });
  }

  const stageStyle = { background: "var(--surface-stage)", border: "1px solid var(--ink-line)", borderRadius: "var(--radius-lg)", backgroundImage: "radial-gradient(rgba(255,255,255,0.045) 1px, transparent 1px)", backgroundSize: "22px 22px", overflow: "hidden", marginBottom: "0.7rem" };
  const plotBlock = { padding: "0.55rem 0.7rem 0.35rem" };
  const h4 = { margin: "0 0 0.4rem", fontSize: "var(--text-body)", fontWeight: "var(--weight-semibold)", color: "var(--text-on-stage)", display: "flex", justifyContent: "space-between", alignItems: "baseline" };
  const meta = { fontWeight: 400, color: "var(--text-faint)", fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)" };

  return (
    <div style={{ maxWidth: 1080 }}>
      <div style={{ display: "flex", gap: "0.7rem", alignItems: "flex-end", flexWrap: "wrap", marginBottom: "0.85rem" }}>
        <div style={{ display: "flex", gap: "0.35rem", alignItems: "flex-end" }}>
          <Button size="sm" disabled={sel <= 0} onClick={() => step(-1)}>‹ Prev</Button>
          <TextField label="Spectrum" type="number" value={sel} width="5rem" onChange={(e) => { const v = Number(e.target.value); if (v >= 0 && v < index.length) setSel(v); }} />
          <Button size="sm" disabled={sel >= index.length - 1} onClick={() => step(1)}>Next ›</Button>
        </div>
        <Select label="MS level" value={lvl} onChange={(e) => setLvl(e.target.value)}
          options={[{ value: "all", label: `All (${summary.numSpectra.toLocaleString()})` }, { value: "1", label: "MS1 (564)" }, { value: "2", label: "MS2 (1,120)" }]} />
        <div style={{ display: "flex", gap: "0.35rem", alignItems: "flex-end", marginLeft: "auto" }}>
          <TextField label="XIC m/z" type="number" value={mz} placeholder="445.12" width="6rem" onChange={(e) => setMz(e.target.value)} />
          <TextField label="± tol" type="number" value={tol} suffix="Da" width="4.5rem" onChange={(e) => setTol(e.target.value)} />
          <Button size="sm" variant="primary" disabled={!mz} onClick={extract}>Extract</Button>
          {xic && <Button size="sm" onClick={() => setXic(null)}>Show TIC</Button>}
        </div>
      </div>

      <div style={stageStyle}>
        <div style={plotBlock}>
          <h4 style={h4}>{chromTitle}<span style={meta}>{tic.length} points · click to navigate</span></h4>
          <ChromPlot points={tic} selectedTime={row.time} onPick={selByTime} />
        </div>
        <div style={{ height: 1, background: "var(--ink-line)" }} />
        <div style={plotBlock}>
          <h4 style={h4}>
            Spectrum
            <span style={meta}>{[`#${sel}`, `MS${row.msLevel}`, spec.representation, `RT ${row.time.toFixed(1)} s`, `${spec.peaks.length} pts`, row.msLevel === 2 ? `prec ${spec.precursor}` : null].filter(Boolean).join(" · ")}</span>
          </h4>
          <SpectrumPlot spectrum={spec} mzWindow={xic} />
          <p style={{ margin: "0.25rem 0 0.2rem", fontSize: "var(--text-sm)", color: "var(--text-faint)" }}>
            {spec.representation === "profile" ? "profile spectrum — drawn as a line" : "centroid spectrum — drawn as a stick spectrum"} · scroll to zoom · drag to box-zoom m/z
          </p>
        </div>
      </div>

      <details style={{ marginTop: "0.1rem" }}>
        <summary style={{ cursor: "pointer", fontWeight: "var(--weight-semibold)", fontSize: "var(--text-body)", color: "var(--text-heading)" }}>Spectrum metadata</summary>
        <div style={{ marginTop: "0.4rem" }}>
          <MetaTree label="spectrum" defaultOpen={2} value={{ id: row.id, "MS:1000511": row.msLevel, "MS:1000525": spec.representation, "MS:1000016": row.time, "MS:1000285": row.tic, basePeak: { "MS:1000504": spec.basePeak.mz, "MS:1000505": spec.basePeak.int }, precursor: row.msLevel === 2 ? { "MS:1000744": spec.precursor, "MS:1000041": 2 } : null }} />
        </div>
      </details>
    </div>
  );
}

Object.assign(window, { SummaryView, MetadataView, BrowseView });
