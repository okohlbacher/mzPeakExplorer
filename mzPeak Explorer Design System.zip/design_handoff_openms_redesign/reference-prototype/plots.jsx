/* SVG data-viz for the Browse view + the metadata tree. Responsive via a
   fixed internal viewBox with non-scaling strokes. Colours come from tokens:
   slate plot line, brand-red selection marker, amber XIC band. */

const CV_RE = /^(MS|IMS|UO|PEFF|BTO|NCIT)[:_]\d{4,}/;
function MetaNode({ label, value, depth, defaultOpen }) {
  const isPrim = value === null || typeof value !== "object";
  const [open, setOpen] = React.useState(depth < defaultOpen);
  const cv = CV_RE.test(label);
  if (isPrim) {
    const isStr = typeof value === "string";
    return (
      <div style={{ display: "flex", alignItems: "baseline", gap: "0.4rem" }}>
        <span style={{ width: "0.9rem", flexShrink: 0 }} />
        <span style={{ color: cv ? "var(--syntax-cv)" : "var(--syntax-key)" }}>{label}</span><span>:</span>
        <span style={{ color: isStr ? "var(--syntax-str)" : "var(--syntax-num)" }}>{value === null ? "null" : isStr ? `"${value}"` : String(value)}</span>
      </div>
    );
  }
  const entries = Array.isArray(value) ? value.map((v, i) => [String(i), v]) : Object.entries(value);
  const preview = Array.isArray(value) ? `[${value.length}]` : `{${Object.keys(value).length}}`;
  return (
    <div>
      <div role="button" tabIndex={0} onClick={() => setOpen((o) => !o)}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setOpen((o) => !o); } }}
        onMouseEnter={(e) => (e.currentTarget.style.background = "var(--surface-panel)")}
        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
        style={{ display: "flex", alignItems: "baseline", gap: "0.4rem", cursor: "pointer", borderRadius: 3 }}>
        <span style={{ width: "0.9rem", display: "inline-block", color: "var(--text-muted)", flexShrink: 0 }}>{open ? "▾" : "▸"}</span>
        <span style={{ color: cv ? "var(--syntax-cv)" : "var(--syntax-key)" }}>{label}</span>
        <span style={{ color: "var(--text-muted)", fontSize: "var(--text-sm)" }}>{preview}</span>
      </div>
      {open && (
        <div style={{ paddingLeft: "1rem", borderLeft: "1px dotted var(--border-default)" }}>
          {entries.length === 0 ? <div style={{ color: "var(--text-muted)", fontSize: "var(--text-sm)", paddingLeft: "1.3rem" }}>(empty)</div>
            : entries.map(([k, v]) => <MetaNode key={k} label={k} value={v} depth={depth + 1} defaultOpen={defaultOpen} />)}
        </div>
      )}
    </div>
  );
}
function MetaTree({ label, value, defaultOpen = 1 }) {
  return (
    <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-data)", lineHeight: "var(--leading-tree)", color: "var(--text-body)" }}>
      <MetaNode label={label} value={value} depth={0} defaultOpen={defaultOpen} />
    </div>
  );
}

const SLATE = "#5468e0", RED = "#d62828", GRID = "#2a323a", AXIS = "#9aa4ad";

function ChromPlot({ points, selectedTime, onPick, title }) {
  const W = 1000, H = 210, padL = 8, padR = 8, padT = 14, padB = 26;
  const ref = React.useRef(null);
  if (!points || points.length === 0) return null;
  const t0 = points[0].time, t1 = points[points.length - 1].time;
  const maxI = Math.max(...points.map((p) => p.intensity));
  const px = (t) => padL + ((t - t0) / (t1 - t0)) * (W - padL - padR);
  const py = (v) => padT + (1 - v / maxI) * (H - padT - padB);
  let d = "";
  points.forEach((p, i) => { d += (i ? "L" : "M") + px(p.time).toFixed(1) + " " + py(p.intensity).toFixed(1) + " "; });
  const selX = selectedTime != null ? px(selectedTime) : null;

  function pick(e) {
    const rect = ref.current.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    const t = t0 + ratio * (t1 - t0);
    onPick && onPick(t);
  }
  const ticks = 5;
  return (
    <svg ref={ref} viewBox={`0 0 ${W} ${H}`} width="100%" height={H} preserveAspectRatio="none"
      onClick={pick} style={{ display: "block", cursor: "crosshair" }}>
      {Array.from({ length: ticks + 1 }).map((_, i) => {
        const x = padL + (i / ticks) * (W - padL - padR);
        const tv = t0 + (i / ticks) * (t1 - t0);
        return (
          <g key={i}>
            <line x1={x} y1={padT} x2={x} y2={H - padB} stroke={GRID} strokeWidth="1" vectorEffect="non-scaling-stroke" />
            <text x={x} y={H - padB + 16} fontSize="11" fill={AXIS} textAnchor="middle" fontFamily="var(--font-mono)" vectorEffect="non-scaling-stroke">{Math.round(tv)}</text>
          </g>
        );
      })}
      <line x1={padL} y1={H - padB} x2={W - padR} y2={H - padB} stroke={AXIS} strokeWidth="1" vectorEffect="non-scaling-stroke" />
      <path d={d} fill="none" stroke={SLATE} strokeWidth="1.4" vectorEffect="non-scaling-stroke" strokeLinejoin="round" />
      {selX != null && (
        <line x1={selX} y1={padT} x2={selX} y2={H - padB} stroke={RED} strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
      )}
    </svg>
  );
}

function SpectrumPlot({ spectrum, mzWindow }) {
  const W = 1000, H = 300, padL = 8, padR = 8, padT = 18, padB = 26;
  if (!spectrum) return null;
  const peaks = spectrum.peaks;
  const mzs = peaks.map((p) => p.mz);
  let lo = Math.min(...mzs), hi = Math.max(...mzs);
  const pad = (hi - lo) * 0.03; lo -= pad; hi += pad;
  const px = (m) => padL + ((m - lo) / (hi - lo)) * (W - padL - padR);
  const py = (v) => padT + (1 - v) * (H - padT - padB);

  // top peaks to label
  const top = [...peaks].sort((a, b) => b.int - a.int).slice(0, 8).sort((a, b) => a.mz - b.mz);
  const labelled = [];
  top.forEach((p) => { const x = px(p.mz); if (!labelled.some((q) => Math.abs(px(q.mz) - x) < 70)) labelled.push(p); });

  const ticks = 6;
  const isProfile = spectrum.representation === "profile";
  let area = "";
  if (isProfile) {
    area = `M ${px(peaks[0].mz).toFixed(1)} ${py(0).toFixed(1)} `;
    peaks.forEach((p) => { area += `L ${px(p.mz).toFixed(1)} ${py(p.int).toFixed(1)} `; });
    area += `L ${px(peaks[peaks.length - 1].mz).toFixed(1)} ${py(0).toFixed(1)} Z`;
  }

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} preserveAspectRatio="none" style={{ display: "block" }}>
      {Array.from({ length: ticks + 1 }).map((_, i) => {
        const x = padL + (i / ticks) * (W - padL - padR);
        const mv = lo + (i / ticks) * (hi - lo);
        return (
          <g key={i}>
            <line x1={x} y1={padT} x2={x} y2={H - padB} stroke={GRID} strokeWidth="1" vectorEffect="non-scaling-stroke" />
            <text x={x} y={H - padB + 16} fontSize="11" fill={AXIS} textAnchor="middle" fontFamily="var(--font-mono)" vectorEffect="non-scaling-stroke">{mv.toFixed(0)}</text>
          </g>
        );
      })}
      {mzWindow && (
        <rect x={px(mzWindow.mz - mzWindow.tol)} y={padT} width={px(mzWindow.mz + mzWindow.tol) - px(mzWindow.mz - mzWindow.tol)} height={H - padT - padB} fill="rgba(255,200,0,0.22)" />
      )}
      <line x1={padL} y1={H - padB} x2={W - padR} y2={H - padB} stroke={AXIS} strokeWidth="1" vectorEffect="non-scaling-stroke" />
      {isProfile ? (
        <path d={area} fill="rgba(84,104,224,0.18)" stroke={SLATE} strokeWidth="1.3" vectorEffect="non-scaling-stroke" strokeLinejoin="round" />
      ) : (
        peaks.map((p, i) => (
          <line key={i} x1={px(p.mz)} y1={H - padB} x2={px(p.mz)} y2={py(p.int)} stroke={SLATE} strokeWidth="1.1" vectorEffect="non-scaling-stroke" />
        ))
      )}
      {labelled.map((p, i) => (
        <text key={i} x={px(p.mz)} y={py(p.int) - 5} fontSize="11" fill="var(--plot-label)" textAnchor="middle" fontFamily="var(--font-mono)" vectorEffect="non-scaling-stroke">{p.mz.toFixed(3)}</text>
      ))}
    </svg>
  );
}

Object.assign(window, { MetaTree, ChromPlot, SpectrumPlot });
