/* The mzPeak Explorer app shell. A PERSISTENT chrome — top header + left nav
   rail + bottom file inspector — that stays fixed while the Summary / Metadata
   / Browse views swap in the main pane. Responsive: the rail collapses to a
   horizontal strip on narrow viewports. */

const Ico = (n, extra) => <Icon name={n} style={extra} />;
function refreshIcons() {}

function MiniInspector() {
  const { summary: s } = window.MZ_DATA;
  const row = (k, v) => (
    <div style={{ display: "flex", justifyContent: "space-between", gap: "0.5rem", padding: "0.12rem 0" }}>
      <span style={{ color: "var(--text-muted)" }}>{k}</span>
      <span style={{ fontFamily: "var(--font-mono)", color: "var(--text-secondary)", textAlign: "right" }}>{v}</span>
    </div>
  );
  return (
    <div style={{ borderTop: "1px solid var(--border-default)", padding: "0.6rem 0.7rem", fontSize: "var(--text-sm)" }}>
      <div style={{ fontSize: "var(--text-cap)", textTransform: "uppercase", letterSpacing: "var(--tracking-caps)", color: "var(--text-muted)", marginBottom: "0.35rem" }}>File</div>
      {row("Spectra", s.numSpectra.toLocaleString())}
      {row("m/z", `${s.mzRange[0].toFixed(0)}–${s.mzRange[1].toFixed(0)}`)}
      {row("Layout", s.layout)}
      {row("Imaging", s.isImaging ? "yes" : "no")}
    </div>
  );
}

function App() {
  const [stage, setStage] = React.useState("idle"); // idle | loading | ready
  const [view, setView] = React.useState("summary");
  const [narrow, setNarrow] = React.useState(false);

  React.useEffect(() => {
    const mq = window.matchMedia("(max-width: 760px)");
    const on = () => setNarrow(mq.matches);
    on(); mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  React.useEffect(refreshIcons);

  function open() {
    setStage("loading");
    setView("summary");
    setTimeout(() => setStage("ready"), 650);
  }

  const navItems = [
    { id: "summary", label: "Summary", icon: Ico("layout-dashboard") },
    { id: "metadata", label: "Metadata", icon: Ico("list-tree") },
    { id: "browse", label: "Browse", icon: Ico("activity"), badge: stage === "ready" ? window.MZ_DATA.summary.numSpectra.toLocaleString() : null },
  ];

  const ready = stage === "ready";
  const fileChip = ready && (
    <Badge tone="neutral" mono><Icon name="file" size={13} style={{ marginRight: 2 }} />example.mzpeak</Badge>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "var(--surface-page)" }}>
      <AppHeader
        left={<Logo product="mzPeak Explorer" size={narrow ? 24 : 32} />}
        right={<>
          {fileChip}
          <Button variant={ready ? "secondary" : "primary"} size="sm" iconLeft={Ico("folder-open", { width: 15, height: 15 })} onClick={open}>
            {ready ? "Open file" : "Open demo"}
          </Button>
        </>} />
      <div style={{ height: 2, background: "var(--openms-spectrum)", flexShrink: 0 }} />

      {/* PERSISTENT shell: nav rail + main pane */}
      <div style={{ display: "flex", flex: 1, minHeight: 0, flexDirection: narrow ? "column" : "row" }}>
        <aside style={narrow
          ? { borderBottom: "1px solid var(--border-default)", background: "var(--surface-page)" }
          : { width: 220, flexShrink: 0, borderRight: "1px solid var(--border-default)", display: "flex", flexDirection: "column", background: "var(--surface-page)" }}>
          {narrow ? (
            <div style={{ display: "flex", gap: "0.25rem", padding: "0.4rem 0.5rem", overflowX: "auto" }}>
              {navItems.map((it) => (
                <button key={it.id} onClick={() => ready && setView(it.id)} disabled={!ready}
                  style={{ display: "flex", alignItems: "center", gap: "0.4rem", padding: "0.4rem 0.7rem", border: "none", borderRadius: "var(--radius-sm)", background: view === it.id && ready ? "var(--accent-soft)" : "transparent", color: view === it.id && ready ? "var(--accent-active)" : "var(--text-secondary)", fontWeight: "var(--weight-medium)", fontSize: "var(--text-body)", cursor: ready ? "pointer" : "not-allowed", whiteSpace: "nowrap" }}>
                  {it.icon}{it.label}
                </button>
              ))}
            </div>
          ) : (
            <>
              <SideNav items={navItems.map((it) => ({ ...it, disabled: !ready }))} activeId={view} onSelect={setView} />
              {ready && <MiniInspector />}
            </>
          )}
        </aside>

        <main style={{ flex: 1, minWidth: 0, minHeight: 0, overflow: "auto", padding: "1.1rem 1.3rem" }}>
          {stage === "idle" && (
            <div style={{ maxWidth: 560, margin: "6vh auto 0", textAlign: "center" }}>
              <div style={{ marginBottom: "1rem", display: "flex", justifyContent: "center" }}><Logo size={62} /></div>
              <h2 style={{ margin: "0 0 0.4rem", fontSize: "1.2rem", color: "var(--text-heading)" }}>Inspect an mzPeak file</h2>
              <p style={{ margin: "0 0 1.2rem", color: "var(--text-muted)", fontSize: "var(--text-body)" }}>
                A lightweight, client-side explorer for the mzPeak mass-spectrometry format — summary, metadata browser and a spectrum / chromatogram navigator. The file never leaves your browser.
              </p>
              <DropZone big onFile={open} />
              <p style={{ marginTop: "0.8rem", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>
                or <a href="#" onClick={(e) => { e.preventDefault(); open(); }} style={{ color: "var(--text-link)" }}>load the bundled demo</a>
              </p>
            </div>
          )}
          {stage === "loading" && (
            <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", color: "var(--text-muted)", justifyContent: "center", marginTop: "10vh", fontSize: "var(--text-body)" }}>
              <Icon name="loader-circle" size={18} style={{ animation: "spin 0.9s linear infinite" }} /> Reading file…
            </div>
          )}
          {ready && view === "summary" && <SummaryView />}
          {ready && view === "metadata" && <MetadataView />}
          {ready && view === "browse" && <BrowseView />}
        </main>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
refreshIcons();
